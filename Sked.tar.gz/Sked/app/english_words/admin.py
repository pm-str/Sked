from django.contrib import admin
from .models import Word, Settings

admin.site.register(Word)
admin.site.register(Settings)
