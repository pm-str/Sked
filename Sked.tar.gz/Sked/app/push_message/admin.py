from django.contrib import admin
from .models import AwaitingDelivery

admin.site.register(AwaitingDelivery)